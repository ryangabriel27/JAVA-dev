package RevisaoFPOO.Cadastro;

public class Cachorro extends Animais {

}
