package RevisaoFPOO.Cadastro;

public class Outros extends Animais{
    
}
