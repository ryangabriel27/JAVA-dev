package RevisaoFPOO.Cadastro;

public class Gato extends Animais {
 
}
