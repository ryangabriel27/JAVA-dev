package RevisaoFPOO.Cadastro;

public class Aves extends Animais {

}
